#!/usr/bin/env python3
"""
Automated AOS/LOS scheduler for unattended satellite IQ recording.

Watches a satellite's elevation using a local TLE and starts/stops
rigctld plus the compiled GNU Radio flowgraph around each pass.

Requires: pip install skyfield --break-system-packages

Fill in the configuration block below, then run this script as a
long-lived background process (e.g. via systemd) on the machine that
also runs Gpredict.
"""

import subprocess
import time
from datetime import datetime

from skyfield.api import load, wgs84, EarthSatellite

# ---- Configuration -------------------------------------------------------

# Paste the same TLE you have loaded in Gpredict for this satellite.
TLE_NAME = "DISCO-2"
TLE_LINE1 = "1 68431U 26067R   26170.15874406  .00006996  00000+0  33656-3 0  9999"
TLE_LINE2 = "2 68431  97.4605 128.7132 0002603  40.3522 319.7905 15.19098267 12247"

# Ground station location.
OBSERVER_LAT_DEG = 55.6761   # example: Copenhagen -- set to your QTH
OBSERVER_LON_DEG = 12.5683
OBSERVER_ELEV_M = 18

MIN_ELEVATION_DEG = 20.0          # only record passes above this elevation
RIGCTLD_CMD = ["rigctld", "-m", "1", "-t", "7356"]
FLOWGRAPH_CMD = ["python3", "/home/discosatgs/Automatize_GNU_radio_control/sat_iq_recorder.py"]
CHECK_INTERVAL_S = 2            # how often to re-check elevation

# ---------------------------------------------------------------------------


def main():
    ts = load.timescale()
    sat = EarthSatellite(TLE_LINE1, TLE_LINE2, TLE_NAME, ts)
    ground_station = wgs84.latlon(OBSERVER_LAT_DEG, OBSERVER_LON_DEG,
                                   OBSERVER_ELEV_M)

    rigctld_proc = None
    flowgraph_proc = None
    recording = False

    print(f"[{datetime.now()}] Scheduler started, watching {TLE_NAME}")

    while True:
        t = ts.now()
        topocentric = (sat - ground_station).at(t)
        alt, az, distance = topocentric.altaz()
        elevation = alt.degrees

        if elevation >= MIN_ELEVATION_DEG and not recording:
            print(f"[{datetime.now()}] AOS - elevation {elevation:.1f} deg, "
                  f"starting capture")
            rigctld_proc = subprocess.Popen(RIGCTLD_CMD)
            time.sleep(2)  # give rigctld a moment to bind the port
            flowgraph_proc = subprocess.Popen(FLOWGRAPH_CMD)
            recording = True

        elif elevation < MIN_ELEVATION_DEG and recording:
            print(f"[{datetime.now()}] LOS - elevation {elevation:.1f} deg, "
                  f"stopping capture")
            if flowgraph_proc is not None:
                flowgraph_proc.terminate()
                try:
                    flowgraph_proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    flowgraph_proc.kill()
            if rigctld_proc is not None:
                rigctld_proc.terminate()
                try:
                    rigctld_proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    rigctld_proc.kill()
            recording = False

        time.sleep(CHECK_INTERVAL_S)


if __name__ == "__main__":
    main()
