import threading
import socket
import time
from gnuradio import gr


class blk(gr.sync_block):
    """Polls rigctld over TCP for the current Doppler-corrected frequency in a
    background thread and exposes it via get_freq(). A Variable Function
    Probe block reads get_freq() on a schedule and stores it into a GRC
    variable — this block itself has no sample ports and takes no
    callback parameter, avoiding GRC's fragile raw-expression parameter typing.
    """

    def __init__(self, host='127.0.0.1', port=7356,
                 poll_interval=1.0, initial_freq=437075000):
        gr.sync_block.__init__(
            self, name='Doppler rigctld poller', in_sig=[], out_sig=[])
        self.host = host
        self.port = int(port)
        self.poll_interval = float(poll_interval)
        self._freq = int(initial_freq)
        self._lock = threading.Lock()
        self._stop_flag = threading.Event()
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()

    def get_freq(self):
        with self._lock:
            return self._freq

    def _connect(self):
        return socket.create_connection((self.host, self.port), timeout=3.0)

    def _poll_loop(self):
        sock = None
        while not self._stop_flag.is_set():
            try:
                if sock is None:
                    sock = self._connect()
                sock.sendall(b'f\n')
                data = sock.recv(64).decode(errors='ignore').strip()
                freq = int(float(data))
                if freq:
                    with self._lock:
                        self._freq = freq
            except (OSError, ValueError):
                try:
                    if sock is not None:
                        sock.close()
                except OSError:
                    pass
                sock = None
                time.sleep(1.0)
            time.sleep(self.poll_interval)

    def stop(self):
        self._stop_flag.set()
        return True

    def work(self, input_items, output_items):
        return 0
