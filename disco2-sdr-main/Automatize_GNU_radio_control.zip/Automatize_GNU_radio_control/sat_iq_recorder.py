#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Satellite IQ Recorder with Doppler Correction
# Description: Doppler-corrected raw IQ recorder for 437.075 MHz satellite passes
# GNU Radio version: 3.10.12.0

from datetime import datetime
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import eng_notation
import osmosdr
import time
import sat_iq_recorder_doppler_ctrl_0 as doppler_ctrl_0  # embedded python block
import threading




class sat_iq_recorder(gr.top_block):

    def __init__(self):
        gr.top_block.__init__(self, "Satellite IQ Recorder with Doppler Correction", catch_exceptions=True)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 500000
        self.rigctld_port = rigctld_port = 7356
        self.rigctld_host = rigctld_host = '127.0.0.1'
        self.iq_filename = iq_filename = '/home/discosatgs/SDR_recordings/GNU_Radio_test/pass_' + time.strftime('%Y%m%d_%H%M%S') + '.iq'
        self.center_freq_default = center_freq_default = 437075000
        self.center_freq = center_freq = 0

        ##################################################
        # Blocks
        ##################################################

        self.doppler_ctrl_0 = doppler_ctrl_0.blk(host=rigctld_host, port=rigctld_port, poll_interval=1.0, initial_freq=center_freq_default)
        def _center_freq_probe():
          self.flowgraph_started.wait()
          while True:

            val = self.doppler_ctrl_0.get_freq()
            try:
              try:
                self.doc.add_next_tick_callback(functools.partial(self.set_center_freq,val))
              except AttributeError:
                self.set_center_freq(val)
            except AttributeError:
              pass
            time.sleep(1.0 / (1))
        _center_freq_thread = threading.Thread(target=_center_freq_probe)
        _center_freq_thread.daemon = True
        _center_freq_thread.start()
        self.osmosdr_source_0 = osmosdr.source(
            args="numchan=" + str(1) + " " + 'uhd,type=b200'
        )
        self.osmosdr_source_0.set_time_unknown_pps(osmosdr.time_spec_t())
        self.osmosdr_source_0.set_sample_rate(samp_rate)
        self.osmosdr_source_0.set_center_freq(center_freq, 0)
        self.osmosdr_source_0.set_freq_corr(0, 0)
        self.osmosdr_source_0.set_dc_offset_mode(0, 0)
        self.osmosdr_source_0.set_iq_balance_mode(0, 0)
        self.osmosdr_source_0.set_gain_mode(False, 0)
        self.osmosdr_source_0.set_gain(55, 0)
        self.osmosdr_source_0.set_if_gain(20, 0)
        self.osmosdr_source_0.set_bb_gain(20, 0)
        self.osmosdr_source_0.set_antenna('', 0)
        self.osmosdr_source_0.set_bandwidth(600000, 0)
        self.blocks_file_sink_0 = blocks.file_sink(gr.sizeof_gr_complex*1, iq_filename, True)
        self.blocks_file_sink_0.set_unbuffered(True)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.osmosdr_source_0, 0), (self.blocks_file_sink_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.osmosdr_source_0.set_sample_rate(self.samp_rate)

    def get_rigctld_port(self):
        return self.rigctld_port

    def set_rigctld_port(self, rigctld_port):
        self.rigctld_port = rigctld_port
        self.doppler_ctrl_0.port = self.rigctld_port

    def get_rigctld_host(self):
        return self.rigctld_host

    def set_rigctld_host(self, rigctld_host):
        self.rigctld_host = rigctld_host
        self.doppler_ctrl_0.host = self.rigctld_host

    def get_iq_filename(self):
        return self.iq_filename

    def set_iq_filename(self, iq_filename):
        self.iq_filename = iq_filename
        self.blocks_file_sink_0.open(self.iq_filename)

    def get_center_freq_default(self):
        return self.center_freq_default

    def set_center_freq_default(self, center_freq_default):
        self.center_freq_default = center_freq_default

    def get_center_freq(self):
        return self.center_freq

    def set_center_freq(self, center_freq):
        self.center_freq = center_freq
        self.osmosdr_source_0.set_center_freq(self.center_freq, 0)




def main(top_block_cls=sat_iq_recorder, options=None):
    tb = top_block_cls()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        sys.exit(0)

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    tb.start()
    tb.flowgraph_started.set()

    tb.wait()


if __name__ == '__main__':
    main()
